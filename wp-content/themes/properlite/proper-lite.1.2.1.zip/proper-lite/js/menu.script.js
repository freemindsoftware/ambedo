jQuery( function( $ ){
	$(document).ready(function() {
	  $('#sidr-menu').sidr({ side: 'right' });
	}); 
});
