<?php
get_template_part( 'widgets/contact-info' );
get_template_part( 'widgets/video-widget' );
get_template_part( 'widgets/widget-mt-social' );
get_template_part( 'widgets/widget-mt-cta' );
get_template_part( 'widgets/widget-mt-home-news' );
